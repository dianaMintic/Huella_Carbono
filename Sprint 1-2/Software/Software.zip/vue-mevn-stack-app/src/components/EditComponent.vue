<template>
 <div class="row justify-content-center">
 <div class="col-md-6">
 <!-- Update Student content -->
 </div>
 </div>
</template>
<script>
export default {
 data() {
 return {};
 },
};
</script>
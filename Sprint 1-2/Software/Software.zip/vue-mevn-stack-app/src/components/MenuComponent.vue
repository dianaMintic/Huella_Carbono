<template>
   <div class="row justify-content-center">
    <div class="col-md-6">
      <h1 class="text-center">Menu</h1>

      <div class="section-news">
        <div class="news">
          <div class="news-data">
            <div class="news-image">
              <img src="Bosque home.jpg" height="200px" width="350px" />
            </div>
            <div align ="left">
            <div class="news-text">
              <h2 class="news-title">Tips de Cuidado Ambiental</h2>
              <hr />
              <p class="news-info" style="margin: 0; padding: 0">
                Aprende sobre la huella de carbono ademas de tips para
                prevenirla
              </p>
              <input type="button" value="Leer mas" style="float: center" />
            </div>
          </div>
        </div>
        </div>

   
    </div>
        <div class="news">
          <div class="news-data">
            <div class="news-image">
              <img src="calculadora.jpg" height="200px" width="350px" />
            </div>
            <div class="news-text">
              <h2 class="news-title">Calculadora de huella de Carbono </h2>
              <hr />
              <p class="news-info" style="margin: 0; padding: 0">
                Calcula tu huella de carbono aqui
              </p>
              <div class="container center-h center-v">
              <input type="button" value="Calcular" style="float: center" />
            </div>
          </div>
        </div>
      </div>
    </div>
 </div>
</template>
<script>
<template>
  <div class="row justify-content-center">
    <!-- <div class="col-md-6">
 </div> -->
    <div style="margin-top:150px">
      <h1><strong> Huella de Carbono</strong></h1>
      <h2><strong> Cuidando el medio ambiente</strong></h2>
    </div>
    <!-- <img src="../assets/img/bosque1.jpg" alt="" >
hola -->
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
};
</script>